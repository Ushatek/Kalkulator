package listeners;

import Exceptions.BlednyZakresLiczbyException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import lab.projektmw.DietaZOknami;

/**

 */
public class DietaListener implements ActionListener
{
    private DietaZOknami dietaZOknami;
    
    public DietaListener(DietaZOknami dietaZOknami) 
    {
        this.dietaZOknami = dietaZOknami;
    }
  
    public void oknoPrzekroczonoLimit()
    {
        if(Integer.valueOf(dietaZOknami.getZjedzoneKalorie().getText()) > Integer.valueOf(dietaZOknami.getZapotrzebowanieKalorie().getText()))
        {
            dietaZOknami.oknoPrzekroczonoLimit();
        }
    }
    
    @Override
    public void actionPerformed(ActionEvent e) 
    {
        try
        {
            switch(e.getActionCommand())
            {
                case "Zmien parametry":
                    dietaZOknami.oknoZmienParametry();
                    oknoPrzekroczonoLimit();
                    break;
                case "Wyślij":
                    System.out.println("wyslij");
                    oknoPrzekroczonoLimit();
                    
                    break;
                case "Dodaj z pliku":
                    System.out.println("plik");
                    break;
                case "Aktualizuj parametry":
                    try
                        {
                            //aplikacja nie oblujuje parametrow innych niż całkowite (np 70,5kg)!
                            if(Integer.parseInt(dietaZOknami.getWaga().getText()) < 0 || Integer.parseInt(dietaZOknami.getWzrost().getText()) < 50 || Integer.parseInt(dietaZOknami.getWiek().getText()) < 0
                                    || Integer.parseInt(dietaZOknami.getWaga().getText()) > 300 || Integer.parseInt(dietaZOknami.getWzrost().getText()) > 250 || Integer.parseInt(dietaZOknami.getWiek().getText()) > 130)
                            {
                                throw new BlednyZakresLiczbyException();//wylapuje zly zakres liczbowy
                            }
                            dietaZOknami.getParametrWaga().setText(dietaZOknami.getWaga().getText());
                            dietaZOknami.getParametrWzrost().setText(dietaZOknami.getWzrost().getText());
                            dietaZOknami.getParametrWiek().setText(dietaZOknami.getWiek().getText());
                        }
                        catch(Exception ex)
                        {
                            //wylapuje jesli ktos poda cos innego niz liczbe calkowita i nie zmieni nic w parametrach
                        }                   
                        dietaZOknami.getParametrPlec().setText(dietaZOknami.getPlec().getSelectedItem().toString()); 
                        dietaZOknami.getParametry().setVisible(false);
                        dietaZOknami.liczZapotrzebowanie();//przeliczamy zapotrzebowanie
                    break;
            }
        }
        catch(Exception ex)
        {
        }
    }   
}