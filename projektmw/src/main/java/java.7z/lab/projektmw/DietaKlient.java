package lab.projektmw;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

/**
Klasa łącząca klienta z serwerem
 */
public class DietaKlient 
{
    public void polaczZSerwerem()
    {
        int portSerwera = 12345; //W serwerze ma być taki sam port
        String adresSerwera = "127.0.0.1"; //Jeśli testujesz w sieci zmień to
        Socket socket = null; //To tylko by kompilator nie zwracał błędu
        
        try {
            System.out.println("Lacze sie z adresem = " + adresSerwera);
            socket = new Socket(adresSerwera, portSerwera);
            //socket = new Socket(InetAddress.getByName(adresSerwera), portSerwera);
        } catch (IOException e) {
            System.out.println("Nie udalo sie uzyskac polaczenia");
        }

        try {
            // Buduję strumień wejsciowy skojarzony z gniazdem do komunikacji z serwerem
            BufferedReader in =
                new BufferedReader(
                    new InputStreamReader(socket.getInputStream()));             
            
            String info = in.readLine();
            System.out.println("Serwer napisal do mnie: " + info);
            System.out.println("No i koncze prace");

            in.close();
            socket.close();
        } catch (Exception e) {
        }
    }
}
