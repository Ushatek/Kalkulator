package lab.projektmw;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

/**
Serwer, ktory laczy sie z aplikacja uzytkownika i przekazuje mu informacje o wprowadzonych produktach z bazy danych, dziala on w tle ciagle w watku
 */
public class DietaSerwer extends Thread
{
    private static final int numerPortu = 12345;
    //Obiekt służący do nasłuchiwania klienta
    private ServerSocket socketSerwera;
    
    public DietaSerwer()
    {
        try { //Próbuję zająć port do nasłuchiwania
            socketSerwera = new ServerSocket(numerPortu);
            System.out.println("Serwer juz dziala :)");
        } catch (IOException e) {
            System.out.println("Serwer nie daje sie zainicjalizować :(");
            System.exit(1);
        }
    }
    
    public void uruchom() {
    
        Socket socketKlienta; // przez ten socket serwer będzie rozmawiać

        while (true) { // komunikacja od strony serwera będzie ciągła
            //Zabezpieczenie czy podłączeni jesteśmy do portu
            if (socketSerwera == null) return;

            try {
                //akceptacja klienta - ale wpierw sobie troche poczekamy
                //UWAGA: ServerSocket może jedynie nasłuchiwać
                // podłączających się klientów
                // nie może odbierać ani wysyłać pakietów.
                System.out.println("Czekam na klienta ...");
                
                //Pobieram obiekt do rozmowy
                socketKlienta = socketSerwera.accept();
                System.out.println("Jest klient - wysylam informacje");

                // przygotowanie odpowiedniego strumienia
                PrintWriter theWriter =
                    new PrintWriter(
                        new OutputStreamWriter(socketKlienta.getOutputStream()),true);

                //wysłanie komunikatu - poprzez strumień skojarzony z gniazdem
                // theWriter potrafi zapisywać do gniazda - klient sobie odbierze
                theWriter.println("Dlaczego mnie budzisz? Masz cos pilnego?");

                //poniższego nie musimy robić ze względu na użycie PrintWriter
                //z dodatkową wartością true w konstruktorze -
                //println już opróżniło bufor samo.
                // theWriter.flush();

                //przerywam połączenie, zamykając strumień i socket

                System.out.println("Przerywam polaczenie");
                theWriter.close();
                socketKlienta.close();
            } catch (IOException e) {
                System.out.println("Coś się nie udało!\nKończę pracę.");
                System.exit(1);
            }
        }
    }
}
