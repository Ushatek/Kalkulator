package lab.projektmw;

/**

 */
public class Projektmw 
{

    public static void main(String[] args) 
    {
        //uruchamiamy najpier serwer
        new DietaSerwer();
        //potem aplikacje klienta na ktorej wykonujemy akcje
        new DietaZOknami();
    }
}
