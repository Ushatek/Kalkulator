package lab.projektmw;

import java.awt.GridLayout;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import listeners.DietaListener;

/**
Klasa ktora docelowo wywolamy, buduje aplikacje z oknami dialogowymi, dziedziczy po klasie dieta budujacej okno glowne
 */
public class DietaZOknami extends Dieta
{    
    private JLabel wiekNapis;
    private JLabel waganapis;
    private JLabel wzrostNapis;
    private JLabel plecNapis;
    private JTextField waga;
    private JTextField wzrost;
    private JTextField wiek;
    private JComboBox plec;
    private JPanel panelGlownyParametry;
    private JPanel panelParametry;
    private JButton wyslijNoweParametry;
    private DietaListener listener;
    private JDialog parametry;

    public JTextField getWaga() {
        return waga;
    }

    public JTextField getWzrost() {
        return wzrost;
    }

    public JTextField getWiek() {
        return wiek;
    }

    public JComboBox getPlec() {
        return plec;
    }

    public JPanel getPanelGlownyParametry() {
        return panelGlownyParametry;
    }

    public JPanel getPanelParametry() {
        return panelParametry;
    }

    public JButton getWyslijNoweParametry() {
        return wyslijNoweParametry;
    }

    public DietaListener getListener() {
        return listener;
    }

    public JDialog getParametry() {
        return parametry;
    }

    public void setWaga(JTextField waga) {
        this.waga = waga;
    }

    public void setWzrost(JTextField wzrost) {
        this.wzrost = wzrost;
    }

    public void setWiek(JTextField wiek) {
        this.wiek = wiek;
    }

    public void setPlec(JComboBox plec) {
        this.plec = plec;
    }

    public void setPanelGlownyParametry(JPanel panelGlownyParametry) {
        this.panelGlownyParametry = panelGlownyParametry;
    }

    public void setPanelParametry(JPanel panelParametry) {
        this.panelParametry = panelParametry;
    }

    public void setWyslijNoweParametry(JButton wyslijNoweParametry) {
        this.wyslijNoweParametry = wyslijNoweParametry;
    }

    public void setListener(DietaListener listener) {
        this.listener = listener;
    }

    public void setParametry(JDialog parametry) {
        this.parametry = parametry;
    }
    
    public DietaZOknami()
    {
        super();
        dodajListenery();
    }
    
    //funkcja wywolujaca ostrzegawcze okno dialogowe po dodaniu produktu, gdy przekroczylismy kalorie
    public void oknoPrzekroczonoLimit()
    {
        JOptionPane.showMessageDialog(getPanelGlowny(), "Przekroczono limit kalorii");
    }
    //funkcja budujaca okno do zmiany parametrow waga, wzrost itp
    public void oknoZmienParametry()
    {
        String[] tablicaPlec = {"Mężczyzna", "Kobieta"};//tablica z mozliwymi plciami do wyboru
        
        parametry = new JDialog();
        parametry.setTitle("Zmiana parametrów");
        parametry.setSize(390, 150);
        parametry.setLocationRelativeTo(getPanelGlowny());//srodkujemy wzgledem panelu glownego
        
        panelGlownyParametry = new JPanel();
        panelGlownyParametry.setLayout((new BoxLayout(panelGlownyParametry, BoxLayout.Y_AXIS)));
        
        panelParametry = new JPanel(new GridLayout(2, 4));
        panelParametry.setAlignmentX(JPanel.CENTER_ALIGNMENT);
        waganapis = new JLabel("Waga [kg]");
        waganapis.setHorizontalAlignment(JLabel.CENTER);
        wzrostNapis = new JLabel("Wzrost [cm]");
        wzrostNapis.setHorizontalAlignment(JLabel.CENTER);
        wiekNapis = new JLabel("Wiek");
        wiekNapis.setHorizontalAlignment(JLabel.CENTER);
        plecNapis = new JLabel("Płeć");
        plecNapis.setHorizontalAlignment(JLabel.CENTER);
        waga = new JTextField(getParametrWaga().getText());
        waga.setHorizontalAlignment(JTextField.CENTER);
        wzrost = new JTextField(getParametrWzrost().getText());
        wzrost.setHorizontalAlignment(JTextField.CENTER);
        wiek = new JTextField(getParametrWiek().getText());
        wiek.setHorizontalAlignment(JTextField.CENTER);
        plec = new JComboBox(tablicaPlec);

        panelParametry.add(waganapis);
        panelParametry.add(wzrostNapis);
        panelParametry.add(wiekNapis);
        panelParametry.add(plecNapis);
        panelParametry.add(waga);
        panelParametry.add(wzrost);
        panelParametry.add(wiek);
        panelParametry.add(plec);
        
        wyslijNoweParametry = new JButton("Aktualizuj parametry");
        wyslijNoweParametry.addActionListener(listener);

        wyslijNoweParametry.setAlignmentX(JButton.CENTER_ALIGNMENT);
        panelGlownyParametry.add(panelParametry);
        panelGlownyParametry.add(wyslijNoweParametry);
        parametry.add(panelGlownyParametry);
        
        parametry.setVisible(true);
    }
    
    public final void dodajListenery()
    {
        listener = new DietaListener(this);
        getZmienParametry().addActionListener(listener);
        getWyslij().addActionListener(listener);
        getDodajPlik().addActionListener(listener);
    }
}