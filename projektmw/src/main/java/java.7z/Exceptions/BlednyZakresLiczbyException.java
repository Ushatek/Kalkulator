package Exceptions;

/**

 */
public class BlednyZakresLiczbyException extends Exception
{
    public BlednyZakresLiczbyException()
    {
        super("Niewlasciwa liczba");
    }
}
